package com.gameloft.test1.client;


/* 
  * GWT-Ext Widget Library 
  * Copyright 2007 - 2008, GWT-Ext LLC., and individual contributors as indicated 
  * by the @authors tag. See the copyright.txt in the distribution for a 
  * full listing of individual contributors. 
  * 
  * This is free software; you can redistribute it and/or modify it 
  * under the terms of the GNU Lesser General Public License as 
  * published by the Free Software Foundation; either version 3 of 
  * the License, or (at your option) any later version. 
  * 
  * This software is distributed in the hope that it will be useful, 
  * but WITHOUT ANY WARRANTY; without even the implied warranty of 
  * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU 
  * Lesser General Public License for more details. 
  * 
  * You should have received a copy of the GNU Lesser General Public 
  * License along with this software; if not, write to the Free 
  * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 
  * 02110-1301 USA, or see the FSF site: http://www.fsf.org. 
  */  
    
   
 import com.google.gwt.core.client.EntryPoint;  
 import com.gwtext.client.core.EventObject;  
 import com.gwtext.client.widgets.Button;  
 import com.gwtext.client.widgets.Panel;  
 import com.gwtext.client.widgets.Viewport;  
 import com.gwtext.client.widgets.event.ButtonListenerAdapter;  
import com.gwtext.client.widgets.layout.HorizontalLayout;  
import com.gwtext.client.widgets.layout.VerticalLayout;
   
 public class TEST1 implements EntryPoint {  
   
     public void onModuleLoad() {  
         Panel panel = new Panel();  
         panel.setBorder(false);  
         panel.setPaddings(15);  
   
         //create a listener for adding an icon to the Button if not present  
         ButtonListenerAdapter listener = new ButtonListenerAdapter() {  
             public void onClick(Button button, EventObject e) {  
                 button.setIconCls("c-icon");  
                 button.setText("Icon Button");  
             }  
         };  
         Button button = new Button("Set Icon", listener);  
   
         //icon button  
         Button iconButton = new Button("Search", new ButtonListenerAdapter() {  
             public void onClick(Button button, EventObject e) {  
             }  
         });  
         iconButton.setIconCls("search-icon");  
   
         //disabled button  
         Button disabled = new Button("Disabled");  
         disabled.setDisabled(true);  
   
         Panel buttonPanel = new Panel();  
   
         //layout buttons horizontally with 10 pixels between them  
         buttonPanel.setLayout(new VerticalLayout(10));  
         buttonPanel.add(button);  
         buttonPanel.add(iconButton);  
         buttonPanel.add(disabled);  
   
         panel.add(buttonPanel);  
   
         Panel mainPanel = new Panel();  
         mainPanel.setBorder(true);
         mainPanel.setAutoHeight(true);
         mainPanel.setAutoWidth(true);
         mainPanel.setPaddings(10);  
         mainPanel.add(panel);  
         
   
         Viewport viewport = new Viewport(mainPanel);  
     }  
 }